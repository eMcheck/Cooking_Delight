import './App.css';
import Header from './components/Header/Header';

function App() {
  return (
    <div className="App">
      <Header />

      hello world, it's cooking-easy web-site
    </div>
  );
}

export default App;
